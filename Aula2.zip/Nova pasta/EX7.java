import javax.swing.*;

public class EX7{
    public static void main(String[] args){
        char a = (JOptionPane.showInputDialog("Digite o digito de milhar: ")).charAt(0);
        char b = (JOptionPane.showInputDialog("Digite o digito de centena: ")).charAt(0);
        char c = (JOptionPane.showInputDialog("Digite o digito de dezena: ")).charAt(0);
        char d = (JOptionPane.showInputDialog("Digite o digito de unidade: ")).charAt(0);
        String e = "" + a + b + c + d;
        JOptionPane.showMessageDialog(null, e);
    }
} 