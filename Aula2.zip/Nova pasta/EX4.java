import javax.swing.*;

public class EX4{
    public static void main(String[] args){
        int a = Integer.parseInt(JOptionPane.showInputDialog("Digite um dia: "));
        int b = Integer.parseInt(JOptionPane.showInputDialog("Digite um mês: "));
        int c = Integer.parseInt(JOptionPane.showInputDialog("Digite um ano: "));
        JOptionPane.showMessageDialog(null, "A data digitada foi "+ a + "/" + b + "/" + c);
    }
} 