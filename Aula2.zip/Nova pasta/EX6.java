import javax.swing.*;

public class EX6{
    public static void main(String[] args){
        char a = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char b = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char c = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char d = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char e = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char f = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char g = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char h = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char i = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        char j = (JOptionPane.showInputDialog("Digite um caractere: ")).charAt(0);
        JOptionPane.showMessageDialog(null, "" + a + b + c + d + e + f + g + h + i + j);
    }
} 