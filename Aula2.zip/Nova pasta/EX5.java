import javax.swing.*;

public class EX5{
    public static void main(String[] args){
        float a = Float.parseFloat(JOptionPane.showInputDialog("Digite seu peso: "));
        float b = Float.parseFloat(JOptionPane.showInputDialog("Digite sua altura: "));
        JOptionPane.showMessageDialog(null, "Seus dados digitados foram: "+ a + "kg e " + b + "m");
    }
} 