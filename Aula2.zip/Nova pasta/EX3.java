import javax.swing.*;

public class EX3{
    public static void main(String[] args){
        int a = Integer.parseInt(JOptionPane.showInputDialog("Digite um número: "));
        JOptionPane.showMessageDialog(null, "O valor do número digitado é: "+ a);
    }
} 